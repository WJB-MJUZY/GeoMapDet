import torch.nn as nn
import torch.nn.functional as F

# from torch_geometric.nn import SAGEConv
# from torch_geometric.nn import GATConv
from torch_geometric.nn import TAGConv


class GCN(nn.Module):

    def __init__(self,
                 nfeat,
                 nhid,
                 nclass):

        super(GCN, self).__init__()

        self.gc1 = TAGConv(nfeat, nhid)

        self.gc2 = TAGConv(nhid, nclass)

    def forward(self, x, edge_index):

        # edge_index.shape.sample = [2, xxx] {Tensor}

        x = F.relu(
            self.gc1(x, edge_index)
        )

        x = self.gc2(x, edge_index)

        return F.log_softmax(x, dim=1)
