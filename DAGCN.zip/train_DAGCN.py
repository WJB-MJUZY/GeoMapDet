# encoding=utf-8
# Date: 2020-04-06
# Author: Weijia Bei


import argparse
import csv
import numpy as np

import os
from .time import getDateStringName
import torch
import torch.nn.functional as F
import torch.optim as optim

from .json import write_json

from .utils import \
    pre_load_data, \
    load_data, \
    accuracy, \
    sparse_mx_to_torch_sparse_tensor, \
    normalize_features, \
    normalized_laplacian, rescale_laplacian, chebyshev_polynomial

from .models_DAGCN import GCN

import random


class Config(object):

    def __init__(self):

        self.log_dir_path_1 = "./log"

        if not os.path.exists(self.log_dir_path_1):
            os.mkdir(self.log_dir_path_1)

        self.log_dir_path_2 = self.log_dir_path_1 + '/' + getDateStringName()

        if not os.path.exists(self.log_dir_path_2):
            os.mkdir(self.log_dir_path_2)
        # --------------------------------------------------------------------------------------------------------------

        self.dataset_root_path = "D:\\USBei\\BeiWeijiaPyPackages\\" \
                                 "DatasetProcess\\Dizhitu_graph\\Process\\data\\Dizhitu_graph"

        self.filenames_in_dataset = os.listdir(self.dataset_root_path)
        # --------------------------------------------------------------------------------------------------------------

        self.if_use_Euclidean_attention = True
        # self.if_use_Euclidean_attention = False

        self.if_save_model = True
        # self.if_save_model = False

        # self.if_skip_training = True
        self.if_skip_training = False
        # --------------------------------------------------------------------------------------------------------------

        self.log_record_loss_acc_csv = "log_record_loss_acc_" + getDateStringName() + ".csv"

        mode_log_record_loss_acc_csv = "a+"

        self.f_log_record_loss_acc_csv = open(self.log_record_loss_acc_csv,
                                              mode=mode_log_record_loss_acc_csv,
                                              encoding="utf-8", newline='')

        self.writer_log_record_loss_acc_csv = csv.writer(self.f_log_record_loss_acc_csv,
                                                         delimiter=',')

        self.filename_list_for_test_set = ['7', '17']

        self.filename_id_list_for_test_set = list()

        for filename in self.filename_list_for_test_set:

            id_of_the_filename = self.filenames_in_dataset.index(filename)

            self.filename_id_list_for_test_set.append(id_of_the_filename)
        # --------------------------------------------------------------------------------------------------------------

        self.device = 'cuda'
        # --------------------------------------------------------------------------------------------------------------


cfg_1 = Config()
# ----------------------------------------------------------------------------------------------------------------------

# Training settings
parser = argparse.ArgumentParser()

parser.add_argument('--seed',
                    type=int,
                    default=1,
                    help='Random seed.')

parser.add_argument('--epochs',
                    type=int,
                    default=128,
                    help='Number of epochs to train.')

parser.add_argument('--lr',
                    type=float,
                    default=0.01,
                    help='Initial learning rate.')

parser.add_argument('--weight_decay',
                    type=float,
                    default=5e-4,
                    help='Weight decay (L2 loss on parameters).')

parser.add_argument('--hidden',
                    type=int,
                    default=32,
                    help='Number of hidden units.')

k_neighbor_order = 1
# ----------------------------------------------------------------------------------------------------------------------

args = parser.parse_args()
# ----------------------------------------------------------------------------------------------------------------------


def init_seeds(seed):

    random.seed(seed)

    os.environ['PYTHONHASHSEED'] = str(seed)

    np.random.seed(seed)

    torch.manual_seed(seed)
    # sets the seed for generating random numbers.
    torch.cuda.manual_seed(seed)
    # Sets the seed for generating random numbers for the current GPU.
    # It’s safe to call this function if CUDA is not available;
    # in that case, it is silently ignored.
    torch.cuda.manual_seed_all(seed)
    # Sets the seed for generating random numbers on all GPUs.
    # It’s safe to call this function if CUDA is not available;
    # in that case, it is silently ignored.

    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


init_seeds(args.seed)
# ----------------------------------------------------------------------------------------------------------------------


def train():

    model.train()

    for order_i_2 in range(len(adj_list_mother_list)):

        features_1 = features_after_preprocess_list[order_i_2]
        adj_list_1 = adj_list_mother_list[order_i_2]
        labels_1 = labels_list[order_i_2]

        idx_train = idx_train_list[order_i_2]
        # --------------------------------------------------------------------------------------------------------------

        this_sample_num = raw_adj_list[order_i_2].shape[0]

        factor = this_sample_num / samples_total_num
        # --------------------------------------------------------------------------------------------------------------

        output = model(features_1, adj_list_1)

        # The average of the losses in this batch.
        loss_train = F.nll_loss(output[idx_train], labels_1[idx_train])

        # The average of the accuracy in this batch
        acc_train = accuracy(output[idx_train], labels_1[idx_train])

        loss_train.backward()

        optimizer.step()

        optimizer.zero_grad()
        # --------------------------------------------------------------------------------------------------------------

        global train_average_acc_for_a_epoch
        train_average_acc_for_a_epoch += factor * acc_train.item()

        global train_average_loss_for_a_epoch
        train_average_loss_for_a_epoch += factor * loss_train.item()
        # --------------------------------------------------------------------------------------------------------------

        print(
            'Epoch: {:04d}'.format(epoch + 1)
        )
        # --------------------------------------------------------------------------------------------------------------


def test():

    adj_list_mother_list_for_test = list()

    features_after_preprocess_list_for_test = list()
    # ------------------------------------------------------------------------------------------------------------------

    for order_i_for_test in range(len(raw_adj_list_for_test)):

        adj_for_test = raw_adj_list_for_test[order_i_for_test]

        features_for_test = features_list_for_test[order_i_for_test]

        adj_list_for_test, features_for_test = main_pre_process_1(adj_1=adj_for_test, features_1=features_for_test)
        # --------------------------------------------------------------------------------------------------------------

        adj_list_mother_list_for_test.append(adj_list_for_test)

        features_after_preprocess_list_for_test.append(features_for_test)
    # ------------------------------------------------------------------------------------------------------------------

    average_loss_for_a_epoch_for_test = 0
    average_acc_for_a_epoch_for_test = 0
    # ------------------------------------------------------------------------------------------------------------------

    model.eval()

    for order_i_2 in range(len(adj_list_mother_list_for_test)):

        features_1 = features_after_preprocess_list_for_test[order_i_2]

        adj_list_1 = adj_list_mother_list_for_test[order_i_2]

        labels_1 = labels_list_for_test[order_i_2]
        # --------------------------------------------------------------------------------------------------------------

        idx_test = idx_train_list_for_test[order_i_2]

        features_1 = features_1.cuda()

        for adj_i_1 in range(len(adj_list_1)):

            adj_list_1[adj_i_1] = adj_list_1[adj_i_1].cuda()

        labels_1 = labels_1.cuda()

        idx_test = idx_test.cuda()
        # --------------------------------------------------------------------------------------------------------------

        this_samples_num_for_test = raw_adj_list_for_test[order_i_2].shape[0]

        factor = this_samples_num_for_test / samples_total_num_for_test
        # --------------------------------------------------------------------------------------------------------------

        output = model(features_1, adj_list_1)

        loss_test = F.nll_loss(output[idx_test], labels_1[idx_test])

        acc_test = accuracy(output[idx_test], labels_1[idx_test])
        # --------------------------------------------------------------------------------------------------------------

        average_loss_for_a_epoch_for_test += factor * loss_test.item()
        average_acc_for_a_epoch_for_test += factor * acc_test.item()
    # ------------------------------------------------------------------------------------------------------------------

    print(
        "Test set results:",
        "test_loss= {:.4f}".format(average_loss_for_a_epoch_for_test),
        "test_accuracy= {:.4f}".format(average_acc_for_a_epoch_for_test)
    )
    # ------------------------------------------------------------------------------------------------------------------


def accuracy_see_testing_results(output, labels, order_i_for_testing_file):

    preds = output.max(1)[1].type_as(labels)

    correct = preds.eq(labels).double()
    # ------------------------------------------------------------------------------------------------------------------

    acc = correct.sum() / len(labels)

    print("\ntesting acc=", acc)
    # ------------------------------------------------------------------------------------------------------------------

    success_pred_label_and_num_dict = dict()

    failed_pred_label_and_num_dict = dict()

    real_label_and_pred_label_num_dict = dict()

    for order_i_2 in range(correct.shape[0]):

        label_name = whole_dataset_one_hot_the_related_id_to_label.get(
            int(labels[order_i_2]), "None"
        )

        pred_label_name = whole_dataset_one_hot_the_related_id_to_label.get(
            int(preds[order_i_2]), "None"
        )

        if_correct = int(correct[order_i_2])

        if if_correct == 1:

            num = success_pred_label_and_num_dict.get(label_name, 0)

            success_pred_label_and_num_dict[label_name] = num + 1

        elif if_correct == 0:

            num = failed_pred_label_and_num_dict.get(label_name, 0)

            failed_pred_label_and_num_dict[label_name] = num + 1

        num = real_label_and_pred_label_num_dict.get(label_name + "_" + pred_label_name, 0)

        real_label_and_pred_label_num_dict[label_name + "_" + pred_label_name] = num + 1
    # ------------------------------------------------------------------------------------------------------------------

    target_path_temp = cfg_1.log_dir_path_2 + "/" + \
        "log_testing_results_" + getDateStringName() + \
        "_a1_" + "predicting_results_order_i=" + str(order_i_for_testing_file) + \
        ".json"

    write_json(mode='w',
               target_path=target_path_temp,
               content_dict=real_label_and_pred_label_num_dict)
    # ------------------------------------------------------------------------------------------------------------------


def test_see_results():

    adj_list_mother_list_for_test = list()

    features_after_preprocess_list_for_test = list()
    # ------------------------------------------------------------------------------------------------------------------

    for order_i_for_test in range(len(raw_adj_list_for_test)):

        adj_for_test = raw_adj_list_for_test[order_i_for_test]

        features_for_test = features_list_for_test[order_i_for_test]

        adj_list_for_test, features_for_test = main_pre_process_1(adj_1=adj_for_test, features_1=features_for_test)
        # --------------------------------------------------------------------------------------------------------------

        adj_list_mother_list_for_test.append(adj_list_for_test)

        features_after_preprocess_list_for_test.append(features_for_test)
    # ------------------------------------------------------------------------------------------------------------------

    average_loss_for_a_epoch_for_test = 0
    average_acc_for_a_epoch_for_test = 0
    # ------------------------------------------------------------------------------------------------------------------

    model.eval()

    for order_i_2 in range(len(adj_list_mother_list_for_test)):

        features_1 = features_after_preprocess_list_for_test[order_i_2]

        adj_list_1 = adj_list_mother_list_for_test[order_i_2]

        labels_1 = labels_list_for_test[order_i_2]
        # --------------------------------------------------------------------------------------------------------------

        idx_test = idx_train_list_for_test[order_i_2]

        features_1 = features_1.cuda()

        for adj_i_1 in range(len(adj_list_1)):

            adj_list_1[adj_i_1] = adj_list_1[adj_i_1].cuda()

        labels_1 = labels_1.cuda()

        idx_test = idx_test.cuda()
        # --------------------------------------------------------------------------------------------------------------

        this_samples_num_for_test = raw_adj_list_for_test[order_i_2].shape[0]

        factor = this_samples_num_for_test / samples_total_num_for_test
        # --------------------------------------------------------------------------------------------------------------

        output = model(features_1, adj_list_1)

        loss_test = F.nll_loss(output[idx_test], labels_1[idx_test])

        acc_test = accuracy(output[idx_test], labels_1[idx_test])
        # --------------------------------------------------------------------------------------------------------------

        accuracy_see_testing_results(
            output[idx_test], labels_1[idx_test],
            order_i_2
        )
        # --------------------------------------------------------------------------------------------------------------

        average_loss_for_a_epoch_for_test += factor * loss_test.item()
        average_acc_for_a_epoch_for_test += factor * acc_test.item()
    # ------------------------------------------------------------------------------------------------------------------

    print(
        "Test set results:",
        "test_loss= {:.4f}".format(average_loss_for_a_epoch_for_test),
        "test_accuracy= {:.4f}".format(average_acc_for_a_epoch_for_test)
    )
    # ------------------------------------------------------------------------------------------------------------------


def main_pre_process_1(
    adj_1, features_1
):
    features_1 = normalize_features(features_1)
    # ------------------------------------------------------------------------------------------------------------------

    adj_1 = normalized_laplacian(adj=adj_1)

    adj_1 = rescale_laplacian(laplacian=adj_1)

    adj_list_1 = chebyshev_polynomial(L_scaled=adj_1, k=k_neighbor_order)

    for adj_i_1 in range(len(adj_list_1)):

        adj_list_1[adj_i_1] = sparse_mx_to_torch_sparse_tensor(adj_list_1[adj_i_1])
        # --------------------------------------------------------------------------------------------------------------

    return adj_list_1, features_1


def get_nfeats():

    return features_list[0].shape[1]


def get_nclass():

    nclass = 0

    for labels_1 in labels_list:

        temp_nclass = labels_1.max().item() + 1

        if temp_nclass > nclass:

            nclass = temp_nclass

    return nclass


def make_for_the_test_set(raw_adj_list1, features_list1, labels_list1, idx_train_list1, filename_id_list_for_test_set):

    raw_adj_list_for_test_1 = list()

    features_list_for_test_1 = list()

    labels_list_for_test_1 = list()

    idx_train_list_for_test_1 = list()

    for chosen_id in filename_id_list_for_test_set:

        raw_adj_list_for_test_1.append(
            raw_adj_list1[chosen_id]
        )

        features_list_for_test_1.append(
            features_list1[chosen_id]
        )

        labels_list_for_test_1.append(
            labels_list1[chosen_id]
        )

        idx_train_list_for_test_1.append(
            idx_train_list1[chosen_id]
        )

    for chosen_id in filename_id_list_for_test_set:

        del raw_adj_list1[chosen_id]

        del features_list1[chosen_id]

        del labels_list1[chosen_id]

        del idx_train_list1[chosen_id]

    return \
        raw_adj_list1, features_list1, labels_list1, idx_train_list1, \
        raw_adj_list_for_test_1, features_list_for_test_1, labels_list_for_test_1, idx_train_list_for_test_1


if __name__ == "__main__":

    whole_dataset_label_to_one_hot_array, \
        whole_dataset_one_hot_the_related_id_to_label = \
        pre_load_data(
            root_path=cfg_1.dataset_root_path,
            filename_list=cfg_1.filenames_in_dataset
        )

    # Load data
    raw_adj_list, features_list, labels_list, idx_train_list = \
        load_data(
            root_path=cfg_1.dataset_root_path,
            filename_list=cfg_1.filenames_in_dataset,
            if_use_Euclidean_attention=cfg_1.if_use_Euclidean_attention,
            whole_dataset_label_to_one_hot_array=whole_dataset_label_to_one_hot_array
        )
    # ------------------------------------------------------------------------------------------------------------------

    raw_adj_list, features_list, labels_list, idx_train_list, \
        raw_adj_list_for_test, \
        features_list_for_test, \
        labels_list_for_test, \
        idx_train_list_for_test = \
        make_for_the_test_set(
            raw_adj_list, features_list, labels_list, idx_train_list,
            cfg_1.filename_id_list_for_test_set
        )
    # ------------------------------------------------------------------------------------------------------------------

    samples_total_num = 0

    for order_i in range(len(raw_adj_list)):

        samples_total_num += raw_adj_list[order_i].shape[0]

    samples_total_num_for_test = 0

    for order_i in range(len(raw_adj_list_for_test)):

        samples_total_num_for_test += raw_adj_list_for_test[order_i].shape[0]
    # ------------------------------------------------------------------------------------------------------------------

    adj_list_mother_list = list()

    features_after_preprocess_list = list()

    for order_i in range(len(raw_adj_list)):

        adj = raw_adj_list[order_i]

        features = features_list[order_i]

        adj_list, features = main_pre_process_1(adj_1=adj, features_1=features)
        # --------------------------------------------------------------------------------------------------------------

        adj_list_mother_list.append(adj_list)

        features_after_preprocess_list.append(features)
    # ------------------------------------------------------------------------------------------------------------------

    support = k_neighbor_order + 1

    model = GCN(
        nfeat=get_nfeats(),
        nhid=args.hidden,
        nclass=get_nclass(),
        support=support
    )

    model.to(cfg_1.device)
    # ------------------------------------------------------------------------------------------------------------------

    """Backed up codes (202009182319)
    
    optimizer = optim.Adam(
        model.parameters(),
        lr=args.lr, weight_decay=args.weight_decay
    )
    """
    optimizer = optim.Adam(
        model.parameters(),
        lr=args.lr, weight_decay=args.weight_decay
    )
    # ------------------------------------------------------------------------------------------------------------------

    for order_i_1 in range(len(adj_list_mother_list)):

        features_after_preprocess_list[order_i_1] = features_after_preprocess_list[order_i_1].cuda()

        labels_list[order_i_1] = labels_list[order_i_1].cuda()

        idx_train_list[order_i_1] = idx_train_list[order_i_1].cuda()
        # --------------------------------------------------------------------------------------------------------------

        for adj_i in range(

            len(adj_list_mother_list[order_i_1])
        ):
            adj_list_mother_list[order_i_1][adj_i] = \
                adj_list_mother_list[order_i_1][adj_i].cuda()
    # ------------------------------------------------------------------------------------------------------------------

    acc_record = 0

    train_average_loss_for_a_epoch = 0
    train_average_acc_for_a_epoch = 0
    # ------------------------------------------------------------------------------------------------------------------

    if not cfg_1.if_skip_training:

        for epoch in range(args.epochs):

            train()

            print(
                'loss_train: {:.4f}'.format(train_average_loss_for_a_epoch),
                'acc_train: {:.4f}'.format(train_average_acc_for_a_epoch)
            )

            cfg_1.writer_log_record_loss_acc_csv.writerow(
                [train_average_loss_for_a_epoch, train_average_acc_for_a_epoch]
            )

            acc_record = train_average_acc_for_a_epoch

            train_average_loss_for_a_epoch = 0
            train_average_acc_for_a_epoch = 0

        if cfg_1.if_save_model:

            saved_model_path = "./" + "GCN_Model_train_acc=" + \
                               str(acc_record) + "_" + getDateStringName() + ".pth"

            torch.save(model.state_dict(), saved_model_path)

            print("LOG: Please input a character you like, to load the model file just saved ... ")
            your_input = input()
            print("LOG: Your input is : ", your_input)

            model.load_state_dict(torch.load(saved_model_path))

        cfg_1.f_log_record_loss_acc_csv.close()
    else:

        print("LOG: Please input the weight file path ... ")

        model.load_state_dict(torch.load(input()))
    # ------------------------------------------------------------------------------------------------------------------

    # Testing
    test()

    test_see_results()
    # ------------------------------------------------------------------------------------------------------------------
