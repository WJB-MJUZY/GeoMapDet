# encoding=utf-8
# Date: 2020-04-06
# Author: Weijia Bei


import datetime


def change_date_format_v1(date_format_str_bad):

    split_list = date_format_str_bad.split("-")

    year = split_list[0]

    month = split_list[1]

    day = split_list[2]

    rest_str_list = split_list[3].split(":")

    hour = rest_str_list[0]

    minute = rest_str_list[1]

    second = rest_str_list[2]

    return year + "_" + month + "_" + day + "_" + hour + "_" + minute + "_" + second


def getDateStringName():

    nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在的时间
    construct1 = nowTime.split('-')

    year = construct1[0]
    month = construct1[1]
    day = ((construct1[2]).split(' '))[0]

    minPart = ((construct1[2]).split(' '))[1]
    construct1 = minPart.split(":")

    hour = construct1[0]
    mint = construct1[1]
    sec = construct1[2]

    return year + "_" + month + "_" + day + "_" + hour + "_" + mint + "_" + sec


def get_time_info(date_name):

    split_parts = date_name.split('_')

    year = split_parts[0]

    month = split_parts[1]

    day = split_parts[2]

    hour = split_parts[3]

    minute = split_parts[4]

    second = split_parts[5]

    return year, month, day, hour, minute, second


def get_time_format_1_compare_past_and_now(past_date_name, now_date_name):

    if ":" in past_date_name:
        past_date_name = change_date_format_v1(past_date_name)

    year_past, month_past, day_past, hour_past, minute_past, second_past = \
        get_time_info(past_date_name)

    year_now, month_now, day_now, hour_now, minute_now, second_now = \
        get_time_info(now_date_name)

    if year_now != year_past:
        return year_past + '.' + month_past + '.' + day_past
    else:
        if month_now != month_past:
            return month_past + "." + day_past
        else:
            if day_now != day_past:
                day_difference = int(day_now) - int(day_past)
                return str(day_difference) + "天前"
            else:
                hour_difference = int(hour_now) - int(hour_past)
                if hour_difference > 0:
                    return str(hour_difference) + "小时前"
                else:
                    minute_difference = int(minute_now) - int(minute_past)
                    if minute_difference > 0:
                        return str(minute_difference) + "分钟前"
                    else:
                        second_difference = int(second_now) - int(second_past)
                        if second_difference > 0:
                            return "刚刚"


if __name__ == "__main__":

    now_date_name_1 = getDateStringName()

    date_name_1 = "2019_10_14_10_27_10"
    print(get_time_format_1_compare_past_and_now(date_name_1, now_date_name_1))
