# encoding=utf-8
# Date: 2020-01-22
# Author: Weijia Bei


import json
import os


def create_an_empty_json(target_path):

    if not os.path.exists(target_path):

        f_1 = open(target_path, 'w')
        f_1.close()


def write_json(mode, target_path, content_dict):

    a = json.dumps(content_dict)
    b = str(a) + "\n"

    json_f = open(target_path, mode=mode)
    json_f.write(b)
    json_f.close()

    return '1'


def read_json_for_a_line(target_path):

    f2 = open(target_path, mode='r', encoding="utf-8")

    rline2 = None
    for line2 in f2.readlines():
        rline2 = json.loads(line2)
        return rline2

    return rline2


def read_json_for_all_lines(target_path):

    dict_list = list()

    if not os.path.exists(target_path):
        return dict_list

    f_1 = open(target_path, mode='r', encoding="utf-8")
    for line in f_1.readlines():
        rline = json.loads(line)

        dict_list.append(rline)

    return dict_list
