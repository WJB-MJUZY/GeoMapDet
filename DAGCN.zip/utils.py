import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg.eigen.arpack import eigsh, ArpackNoConvergence
import torch


def get_label_to_one_hot_array(labels):

    classes = set(labels)

    classes_dict = {
        class_name_: np.identity(
            len(classes)
        )[id_, :]
        for id_, class_name_ in enumerate(classes)
    }

    return classes_dict


def get_one_hot_the_related_id_to_label(label_to_one_hot_array):

    one_hot_array_to_label = {
        v.tolist().index(1): k
        for k, v in label_to_one_hot_array.items()
    }
    return one_hot_array_to_label


def encode_onehot(labels):

    classes = set(labels)

    classes_dict = {
        class_name_: np.identity(
            len(classes)
        )[id_, :]
        for id_, class_name_ in enumerate(classes)
    }

    labels_onehot = np.array(
        list(map(classes_dict.get, labels)),
        dtype=np.int32
    )
    return labels_onehot


def encode_onehot_by_pre(labels, whole_dataset_label_to_one_hot_array):

    labels_onehot = np.array(
        list(
            map(whole_dataset_label_to_one_hot_array.get, labels)
        ),
        dtype=np.int32
    )
    return labels_onehot


def main_load_data_use_Euclidean_attention(dir_path, filename, whole_dataset_label_to_one_hot_array):

    content_data_path = dir_path + "\\" + filename + ".content"

    idx_features_labels = np.genfromtxt(
        content_data_path,
        dtype=np.dtype(str)
    )

    features = sp.csr_matrix(
        idx_features_labels[:, 1: -1],
        dtype=np.float32
    )
    # ------------------------------------------------------------------------------------------------------------------

    labels = encode_onehot_by_pre(idx_features_labels[:, -1], whole_dataset_label_to_one_hot_array)
    # ------------------------------------------------------------------------------------------------------------------

    # build graph
    idx = np.array(idx_features_labels[:, 0], dtype=np.int32)
    # ------------------------------------------------------------------------------------------------------------------

    cite_data_path = dir_path + "\\" + filename + ".weighted_cite"

    data_from_weighted_cite = np.genfromtxt(cite_data_path, dtype=np.float)
    # ------------------------------------------------------------------------------------------------------------------

    row_array = data_from_weighted_cite[:, 0].astype(np.int32)
    col_array = data_from_weighted_cite[:, 1].astype(np.int32)
    weights_array = data_from_weighted_cite[:, 2]

    adj = sp.coo_matrix(
        (
            weights_array,
            (row_array, col_array)
        ),
        shape=(features.shape[0], features.shape[0]),
        dtype=np.float32
    )
    # ------------------------------------------------------------------------------------------------------------------

    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    # ------------------------------------------------------------------------------------------------------------------

    node_num = idx.shape[0]

    idx_train = range(0, node_num)
    # ------------------------------------------------------------------------------------------------------------------

    features = torch.FloatTensor(
        np.array(features.todense())
    )
    labels = torch.LongTensor(
        np.where(labels)[1]
    )
    # ------------------------------------------------------------------------------------------------------------------

    idx_train = torch.LongTensor(idx_train)
    # ------------------------------------------------------------------------------------------------------------------

    return adj, features, labels, idx_train


def main_load_data(dir_path, filename, whole_dataset_label_to_one_hot_array):

    content_data_path = dir_path + "\\" + filename + ".content"

    idx_features_labels = np.genfromtxt(
        content_data_path,
        dtype=np.dtype(str)
    )

    features = sp.csr_matrix(
        idx_features_labels[:, 1: -1],
        dtype=np.float32
    )
    # ------------------------------------------------------------------------------------------------------------------

    labels = encode_onehot_by_pre(idx_features_labels[:, -1], whole_dataset_label_to_one_hot_array)
    # ------------------------------------------------------------------------------------------------------------------

    # build graph
    idx = np.array(idx_features_labels[:, 0], dtype=np.int32)

    idx_map = {
        j: i
        for i, j in enumerate(idx)
    }
    # ------------------------------------------------------------------------------------------------------------------

    cite_data_path = dir_path + "\\" + filename + ".cite"

    edges_unordered = np.genfromtxt(cite_data_path, dtype=np.int32)

    edges = np.array(
        list(
            map(idx_map.get, edges_unordered.flatten())
        ),
        dtype=np.int32
    ).reshape(
        edges_unordered.shape
    )

    adj = sp.coo_matrix(
        (
            np.ones(edges.shape[0]),
            (edges[:, 0], edges[:, 1])
        ),
        shape=(labels.shape[0], labels.shape[0]),
        dtype=np.float32
    )
    # ------------------------------------------------------------------------------------------------------------------

    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    # ------------------------------------------------------------------------------------------------------------------

    node_num = idx.shape[0]

    idx_train = range(0, node_num)
    # ------------------------------------------------------------------------------------------------------------------

    features = torch.FloatTensor(
        np.array(features.todense())
    )
    labels = torch.LongTensor(
        np.where(labels)[1]
    )

    idx_train = torch.LongTensor(idx_train)

    return adj, features, labels, idx_train


def pre_load_data(root_path, filename_list):

    idx_features_labels_mother_list = list()

    for filename in filename_list:

        dir_path = root_path + "\\" + filename

        content_data_path = dir_path + "\\" + filename + ".content"
        # --------------------------------------------------------------------------------------------------------------

        idx_features_labels = np.genfromtxt(
            content_data_path,
            dtype=np.dtype(str)
        )
        # ------------------------------------------------------------------------------------------------------------------

        idx_features_labels_mother_list.extend(
            idx_features_labels[:, -1].tolist().copy()
        )
        # ------------------------------------------------------------------------------------------------------------------

    idx_features_labels_mother_array = np.array(idx_features_labels_mother_list)

    label_to_one_hot_array = get_label_to_one_hot_array(idx_features_labels_mother_array[:])

    one_hot_the_related_id_to_label = get_one_hot_the_related_id_to_label(label_to_one_hot_array)

    return label_to_one_hot_array, one_hot_the_related_id_to_label


def load_data_for_service_procedure(dir_path, filename, if_use_Euclidean_attention=True):

    if if_use_Euclidean_attention:

        content_data_path = dir_path + "\\" + filename + ".content"

        idx_features_labels = np.genfromtxt(
            content_data_path,
            dtype=np.dtype(str)
        )

        features = sp.csr_matrix(
            idx_features_labels[:, 1: -1],
            dtype=np.float32
        )
        # --------------------------------------------------------------------------------------------------------------

        cite_data_path = dir_path + "\\" + filename + ".weighted_cite"

        data_from_weighted_cite = np.genfromtxt(cite_data_path, dtype=np.float)
        # --------------------------------------------------------------------------------------------------------------

        row_array = data_from_weighted_cite[:, 0].astype(np.int32)
        col_array = data_from_weighted_cite[:, 1].astype(np.int32)
        weights_array = data_from_weighted_cite[:, 2]

        adj = sp.coo_matrix(
            (
                weights_array,
                (row_array, col_array)
            ),
            shape=(features.shape[0], features.shape[0]),
            dtype=np.float32
        )
        # ------------------------------------------------------------------------------------------------------------------

        adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
        # ------------------------------------------------------------------------------------------------------------------

        features = torch.FloatTensor(
            np.array(features.todense())
        )
        # ------------------------------------------------------------------------------------------------------------------

        return adj, features
    # ------------------------------------------------------------------------------------------------------------------
    else:
        print("ERROR: `if_use_Euclidean_attention` should be set true ! ")

        exit(0)
    # ------------------------------------------------------------------------------------------------------------------


def load_data(root_path, filename_list, if_use_Euclidean_attention, whole_dataset_label_to_one_hot_array):

    print('Loading {} dataset...'.format(root_path))
    # ------------------------------------------------------------------------------------------------------------------

    adj_list = list()
    features_list = list()
    labels_list = list()

    idx_train_list = list()
    # ------------------------------------------------------------------------------------------------------------------

    for filename in filename_list:

        dir_path = root_path + "\\" + filename

        if if_use_Euclidean_attention:

            adj, features, labels, idx_train = \
                main_load_data_use_Euclidean_attention(
                    dir_path=dir_path, filename=filename,
                    whole_dataset_label_to_one_hot_array=whole_dataset_label_to_one_hot_array
                )
        else:

            adj, features, labels, idx_train = \
                main_load_data(
                    dir_path=dir_path, filename=filename,
                    whole_dataset_label_to_one_hot_array=whole_dataset_label_to_one_hot_array
                )
        # --------------------------------------------------------------------------------------------------------------

        adj_list.append(adj)
        features_list.append(features)
        labels_list.append(labels)

        idx_train_list.append(idx_train)
    # ------------------------------------------------------------------------------------------------------------------

    return adj_list, features_list, labels_list, idx_train_list


def normalize_features(features):

    features_ = features.sum(1).reshape(-1, 1)
    features /= features_

    return features


def normalize_adj_symmetric_style(adj, symmetric=True):

    if symmetric:

        d = sp.diags(np.power(np.array(adj.sum(1)), -0.5).flatten(), 0)

        a_norm = adj.dot(d).transpose().dot(d).tocsr()

    else:

        d = sp.diags(np.power(np.array(adj.sum(1)), -1).flatten(), 0)

        a_norm = d.dot(adj).tocsr()

    return a_norm


def chebyshev_recurrence(T_k_minus_one, T_k_minus_two, L_scaled):

    L_scaled = sp.csr_matrix(L_scaled, copy=True)

    return 2 * L_scaled.dot(T_k_minus_one) - T_k_minus_two


def chebyshev_polynomial(L_scaled, k):

    print("Calculating Chebyshev polynomials up to order {}...".format(k))

    T_k = list()

    T_k.append(
        sp.eye(L_scaled.shape[0]).tocsr()
    )

    T_k.append(L_scaled)

    for i in range(2, k + 1):

        T_k.append(
            chebyshev_recurrence(T_k[-1], T_k[-2], L_scaled)
        )
    # ------------------------------------------------------------------------------------------------------------------

    return T_k


def rescale_laplacian(laplacian):

    try:
        print('Calculating largest eigenvalue of normalized graph Laplacian...')

        largest_eigval = eigsh(laplacian, 1, which='LM', return_eigenvectors=False)[0]

    except ArpackNoConvergence:

        print('Eigenvalue calculation did not converge! Using largest_eigval=2 instead.')

        largest_eigval = 2

    scaled_laplacian = (2. / largest_eigval) * laplacian - sp.eye(laplacian.shape[0])

    return scaled_laplacian


def normalized_laplacian(adj, symmetric=True):

    adj_normalized = normalize_adj_symmetric_style(adj, symmetric)

    laplacian = sp.eye(adj.shape[0]) - adj_normalized

    return laplacian


def normalize(mx):

    rowsum = np.array(mx.sum(1))

    r_inv = np.power(rowsum, -1).flatten()

    r_inv[np.isinf(r_inv)] = 0.

    r_mat_inv = sp.diags(r_inv)

    mx = r_mat_inv.dot(mx)

    return mx


def accuracy(output, labels):

    preds = output.max(1)[1].type_as(labels)

    correct = preds.eq(labels).double()

    correct = correct.sum()

    return correct / len(labels)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):

    sparse_mx = sparse_mx.tocoo().astype(np.float32)

    indices = torch.from_numpy(
        np.vstack(
            (sparse_mx.row, sparse_mx.col)
        ).astype(np.int64)
    )

    values = torch.from_numpy(sparse_mx.data)

    shape = torch.Size(sparse_mx.shape)

    return torch.sparse.FloatTensor(indices, values, shape)
