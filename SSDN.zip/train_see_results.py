# encoding=utf-8
# Date: 2020-02-21
# Author: Weijia Bei


import os
from glob import glob

import numpy as np
import torch as th
import torch.utils.data as data
from tqdm import tqdm

from .DatasetProcess.TemplateSet.ImageProcess.ForLabeling.Drawing.ForPLT.Drawing import plt_show_ground_truth_def_1

from .data import TemplateDataset, load_gt
from .models import FPNSegmentation

tqdm.monitor_interval = 0

th.backends.cudnn.benchmark = False
th.backends.cudnn.deterministic = True


def nms(heat, kernel=3):

    pad = (kernel - 1) // 2

    hmax = th.nn.functional.max_pool2d(
        heat,
        (kernel, kernel),
        stride=1, padding=pad)

    keep = \
        (hmax == heat).float()

    return heat * keep


def seed_all():

    SEED_1 = 32

    np.random.seed(SEED_1)

    th.manual_seed(SEED_1)

    th.cuda.manual_seed(SEED_1)


def kuzushiji_loss(hm, centers, classes, hm_pred, classes_pred):

    assert hm.shape == hm_pred.shape

    hm = hm.to(hm_pred.dtype)

    hm_loss = th.nn.functional.binary_cross_entropy_with_logits(
        hm_pred,
        hm,
        reduction='mean'
    )

    classes_ = []

    for sample_ind in range(len(hm)):

        center = centers[sample_ind]

        center_mask = center[:, 0] != -1

        per_image_letters = center_mask.sum().item()

        if per_image_letters == 0:
            continue

        classes_per_img = classes[sample_ind][center_mask]

        classes_.append(classes_per_img)

    classes = th.cat(classes_, 0)

    classes_loss = th.nn.functional.cross_entropy(
        classes_pred,
        classes,
        reduction='mean'
    )

    total_loss = hm_loss + 0.1 * classes_loss

    return total_loss


def get_num_classes(label_to_int):

    max_value = 0

    for key, value in label_to_int.items():

        if int(value) > max_value:
            max_value = int(value)

    return max_value + 1


def visualize_results(
        hm_pred, classes_pred,
        X_input,
        model, config_1,
        base_w, base_h,
        int_to_label,
        image_log_dir
):
    image_ids, labels = [], []

    classes_embeddings = classes_pred

    hm_pred = \
        nms(
            hm_pred.detach()
        ).cpu(

        ).numpy()  # Attention, hm_pred (heatmap) has been transformed into array type.
    # ------------------------------------------------------------------------------------------------------------------

    # hm_pred.length = 2 = batch_size
    for j in range(len(hm_pred)):

        label_name_list = list()

        hmp = hm_pred[j].squeeze(0)

        hmp_thresholded = \
            hmp > 0.4

        ys, xs = np.where(hmp_thresholded)

        if len(ys) == 0:

            labels.append('')

            continue

        centers = th.stack(
            [th.tensor(xs), th.tensor(ys)], -1
        ).unsqueeze(0)

        gathered_embeddings = \
            model.gather_embeddings(
                classes_embeddings[j: j + 1],
                centers
            )

        classes_preds = model.classes(
            gathered_embeddings.unsqueeze(
                -1
            ).unsqueeze(-1)
        ).squeeze(-1).squeeze(-1)

        classes_preds = classes_preds[:, : config_1.num_classes]

        classes_preds = th.nn.functional.softmax(
            classes_preds.detach(), 1
        ).cpu().numpy()

        per_image_labels = []

        coor_list_for_gt_show = list()

        times = 4

        for center_ind in range(len(ys)):

            x, y = xs[center_ind], ys[center_ind]

            pred_probs = classes_preds[center_ind]

            pred_classes = [pred_probs.argmax()]

            coor_list_for_gt_show.append(
                [int(y) * times, int(x) * times]
            )
            # --------------------------------------------------------------------------------------------------

            for pred_class in pred_classes:

                ll = int_to_label[pred_class]

                per_image_labels.extend([ll, str(x), str(y)])

                if ll not in label_name_list:
                    label_name_list.append(ll)
        # --------------------------------------------------------------------------------------------------------------

        X = X_input.detach().cpu().numpy()

        img = X[j]
        img = img.transpose(
            (1, 2, 0)
        )
        plt_show_ground_truth_def_1(
            img=img, ground_truth_coor_list=coor_list_for_gt_show
        )
        # ------------------------------------------------------------------------------------------------------

        w, h = base_w, base_h

        img = np.zeros((w, h))

        plt_show_ground_truth_def_1(
            img=img, ground_truth_coor_list=coor_list_for_gt_show
        )
        # --------------------------------------------------------------------------------------------------------------

    # delete the log images.
    for file_name in os.listdir(image_log_dir):

        if "mask" in file_name and "jpg" in file_name:
            os.remove(image_log_dir + file_name)
        if "mask" not in file_name and "jpg" in file_name:
            os.remove(image_log_dir + file_name)
    # ------------------------------------------------------------------------------------------------------------------

    return '1'


def main(config_1):

    seed_all()

    os.makedirs(config_1.logdir, exist_ok=True)

    print("Logging to: %s" % config_1.logdir)
    # ------------------------------------------------------------------------------------------------------------------

    train_image_fns = sorted(glob(os.path.join(config_1.train_dir, '*.jpg')))
    # ------------------------------------------------------------------------------------------------------------------

    gt, label_to_int = load_gt(config_1.train_rle)

    int_to_label = {
        v: k
        for k, v in label_to_int.items()
    }

    config_1.num_classes = get_num_classes(label_to_int)

    print("Log: length of train_image_fns: ", len(train_image_fns))
    # ------------------------------------------------------------------------------------------------------------------

    train_image_fns = [
        fn for fn in train_image_fns
        if TemplateDataset.fn_to_id(fn) in gt
    ]

    train_ds = TemplateDataset(
        image_fns=train_image_fns,
        gt_boxes=gt,
        label_to_int=label_to_int, augment=config_1.if_aug,
        if_see_result=config_1.if_see_input_data
    )
    # ------------------------------------------------------------------------------------------------------------------

    if config_1.cache:

        train_ds.cache()
    # ------------------------------------------------------------------------------------------------------------------

    model = FPNSegmentation(config_1.slug,
                            num_classes=config_1.num_classes,
                            pretrained=False)
    # ------------------------------------------------------------------------------------------------------------------

    if config_1.weight is not None:
        print("Loading: %s" % config_1.weight)
        model.load_state_dict(th.load(config_1.weight))
    # ------------------------------------------------------------------------------------------------------------------

    model = model.to(config_1.device)
    # ------------------------------------------------------------------------------------------------------------------

    model.eval()

    train_loader = data.DataLoader(dataset=train_ds,
                                   batch_size=config_1.batch_size,
                                   shuffle=True,
                                   num_workers=config_1.num_workers,
                                   pin_memory=config_1.pin, drop_last=True)

    for i, (X, fns, hm, centers, classes) in enumerate(train_loader):

        print("\nLog: this is one batch...\n")

        X = X.to(
            config_1.device
        ).float()

        hm_pred, classes_pred = model(X, return_embeddings=True)
        # ------------------------------------------------------------------------------------------------------

        """
        
        """
        visualize_results(
            hm_pred=th.sigmoid(hm_pred), classes_pred=classes_pred,
            X_input=X,
            model=model, config_1=config_1,
            base_w=config_1.base_w, base_h=config_1.base_h,
            int_to_label=int_to_label,
            image_log_dir=config_1.image_log_dir
        )
        # --------------------------------------------------------------------------------------------------------------

        print("If you want to exit? (1/0)")

        response = input()

        if response == '1':

            exit(0)
        # --------------------------------------------------------------------------------------------------------------


class Config:

    def __init__(self):

        self.id = 38

        self.logdir = './Logdir'

        self.image_log_dir = "./"
        # --------------------------------------------------------------------------------------------------------------

        self.if_aug = True

        dir_path_1_dataset_kuzushiji = "D:/Dataset_dizhitu_2/"
        # --------------------------------------------------------------------------------------------------------------

        self.train_dir = \
            dir_path_1_dataset_kuzushiji + 'train_images'
        self.test_dir = \
            dir_path_1_dataset_kuzushiji + 'test_images'
        self.train_rle = \
            dir_path_1_dataset_kuzushiji + 'train.csv'
        # --------------------------------------------------------------------------------------------------------------

        self.num_classes = int()
        # --------------------------------------------------------------------------------------------------------------

        self.batch_size = 1
        # --------------------------------------------------------------------------------------------------------------

        self.if_see_input_data = True

        self.if_new_train = False

        if self.if_new_train:

            print("\nLog: config.if_new_train: ", self.if_new_train)

            self.weight = None
        else:

            print("\nLog: config.if_new_train: ",
                  self.if_new_train)
            print("\nNow, please input the existing model filename, "
                  "to continue train: ")
            existing_model_filename = input()

            self.weight = \
                self.logdir + '/' + \
                existing_model_filename
        # --------------------------------------------------------------------------------------------------------------

        self.device = 'cuda'

        self.apex = True
        # --------------------------------------------------------------------------------------------------------------

        self.base_w = 512
        self.base_h = 512
        # --------------------------------------------------------------------------------------------------------------

        self.lr = 5e-5

        self.weight_decay = 1e-4

        self.loss_threshold_for_save_weight = 0.045
        # --------------------------------------------------------------------------------------------------------------

        self.num_workers = 0

        self.pin = False
        # --------------------------------------------------------------------------------------------------------------

        self.slug = 'r101d'
        # --------------------------------------------------------------------------------------------------------------

        self.cache = True
        # --------------------------------------------------------------------------------------------------------------

    def as_dict(self):
        return vars(self)

    def __str__(self):
        return str(self.as_dict())

    def __repr__(self):
        return str(self)


if __name__ == '__main__':

    config = Config()

    main(config)
