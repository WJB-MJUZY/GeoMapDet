# encoding=utf-8
# Date: 2020-02-29
# Author: Weijia Bei


import cv2
import numpy as np
import os


class Config:

    def __init__(self):

        self.dir_path_1_legend_image_depository = \
            "D:/USBei/1_for_FCN_legend"


def func_1_1_get_label_name_and_image_path_dict(config_1):

    label_name_and_image_path_dict = dict()

    dir_path_1_legend_image_depository = config_1.dir_path_1_legend_image_depository

    for file_name in os.listdir(dir_path_1_legend_image_depository):

        label_name = file_name.split(".")[0]

        file_path = dir_path_1_legend_image_depository + '\\' + file_name

        label_name_and_image_path_dict[label_name] = file_path

    return label_name_and_image_path_dict


def func_1_2_make_legend_image(
        label_name_list,
        label_name_and_image_path_dict,
        meta_image_width=48, meta_image_height=32,
        meta_gap_width=16, meta_gap_height=16,
        meta_start_point_x=16, meta_start_point_y=16
):
    whole_legend_image_width = \
        meta_gap_width + meta_image_width + meta_gap_width

    whole_legend_image_height = \
        (meta_gap_height + meta_image_height) * len(label_name_list) + \
        meta_gap_height

    whole_legend_image = np.zeros(
        (whole_legend_image_height, whole_legend_image_width, 3),
        dtype='uint8'
    )
    # ------------------------------------------------------------------------------------------------------------------

    white_RGB_pixel = np.array([255, 255, 255])
    for height_i in range(whole_legend_image_height):
        for width_i in range(whole_legend_image_width):
            whole_legend_image[height_i, width_i] = white_RGB_pixel
    # ------------------------------------------------------------------------------------------------------------------

    label_i = -1

    for label_name in label_name_list:

        # `label_i` starts with 0,
        label_i += 1

        label_image_path = label_name_and_image_path_dict[label_name]

        label_img = cv2.imread(
                label_image_path,
                flags=1
        )
        # Attention:
        #   resize((x, y))
        label_img = cv2.resize(
            label_img,
            (meta_image_width, meta_image_height)
        )
        """
        cv2.imshow("Temp", label_img)
        cv2.waitKey(0)
        # -----------------------------------------------------------------------------------------------------
        """

        label_left_top_x = meta_start_point_x
        label_left_top_y = \
            meta_start_point_y + \
            label_i * (meta_image_height + meta_gap_height)

        label_right_down_x = meta_start_point_x + meta_image_width
        label_right_down_y = \
            meta_start_point_y + meta_image_height + \
            label_i * (meta_image_height + meta_gap_height)
        # --------------------------------------------------------------------------------------------------------------

        whole_legend_image[
            label_left_top_y: label_right_down_y,
            label_left_top_x: label_right_down_x,
            :
        ] = \
            label_img
        # --------------------------------------------------------------------------------------------------------------

    cv2.imshow("Temp", whole_legend_image)
    cv2.waitKey(0)
    # ------------------------------------------------------------------------------------------------------------------


def func_1_make_legend_process(label_name_list):

    config_1 = Config()

    label_name_and_image_path_dict = func_1_1_get_label_name_and_image_path_dict(config_1)

    func_1_2_make_legend_image(
        label_name_list,
        label_name_and_image_path_dict=label_name_and_image_path_dict
    )


if __name__ == "__main__":

    func_1_make_legend_process(

        label_name_list=[
            "crescent", "wave", "bow_and_arrow"
        ]
    )
