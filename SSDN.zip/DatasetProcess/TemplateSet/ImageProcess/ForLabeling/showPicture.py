# encoding=utf-8
# Date: 2020-01-28
# Author: Weijia Bei


import cv2
import matplotlib.pyplot as plt
import os


def show_picture_def_1(img_path,
                       one_grid_length_for_height,
                       one_grid_length_for_row,
                       plt_show_id):

    img_file_name = os.path.basename(img_path)

    img = cv2.cvtColor(cv2.imread(img_path, 1),
                       cv2.COLOR_BGR2RGB)

    plt.subplot(one_grid_length_for_height,
                one_grid_length_for_row,
                plt_show_id)

    plt.title(img_file_name)
    plt.imshow(img)

    plt.show()


def show_picture_def_2(img,
                       one_grid_length_for_height,
                       one_grid_length_for_row,
                       plt_show_id):

    plt.subplot(one_grid_length_for_height,
                one_grid_length_for_row,
                plt_show_id)

    plt.title("Picture")
    plt.imshow(img)

    plt.show()


def show_picture_def_3(img_path,
                       scale=1):

    def draw_circle(event, x, y, flags, param):

        if event == cv2.EVENT_LBUTTONDOWN:

            cv2.circle(img=img,
                       center=(x, y),
                       radius=20,
                       color=(255, 0, 0),
                       thickness=-1)

            print("Log : x : ", x)
            print("Log : y : ", y, "\n")

    # -------------------------------------------------------------------------------------------------------------------

    img_file_name = os.path.basename(img_path)

    img = cv2.cvtColor(cv2.imread(img_path, 1),
                       cv2.COLOR_BGR2RGB)

    # curr_h, curr_w = 512, 512
    curr_h, curr_w = img.shape[: 2]

    img = cv2.resize(img,
                     (curr_h // scale, curr_w // scale))

    cv2.namedWindow(img_file_name,
                    cv2.WINDOW_NORMAL)

    cv2.setMouseCallback(img_file_name,
                         draw_circle)

    cv2.imshow(img_file_name, img)

    cv2.waitKey()

    cv2.destroyAllWindows()

image_path_sample_1 = 'D:/Dataset_kuzushiji/train_images\\100241706_00005_1.jpg'

"""

# ----------------------------------------------------------------------------------------------------------------------

show_picture_def_1(img_path=image_path_sample_1,
                   one_grid_length_for_height=1,
                   one_grid_length_for_row=1,
                   plt_show_id=1)
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
show_picture_def_1(img_path=image_path_sample_1,
                   one_grid_length_for_height=1,
                   one_grid_length_for_row=1,
                   plt_show_id=1)
# ----------------------------------------------------------------------------------------------------------------------

show_picture_def_3(img_path=image_path_sample_1)
"""
