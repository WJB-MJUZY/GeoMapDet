# encoding=utf-8
# Date: 2020-01-28
# Author: Weijia Bei


import cv2
import numpy as np


def put_text_def_1(img_name):

    img = np.zeros(shape=(512, 512))

    font = cv2.FONT_HERSHEY_SIMPLEX

    y_axis = 50
    x_axis = 300

    # org denotes the bottom-left of the first character
    img = cv2.putText(img=img,
                      text="Please ... ",
                      org=(x_axis, y_axis),
                      fontFace=font,
                      fontScale=1.2,
                      color=(255, 255, 255),
                      thickness=2)

    y_axis = 100
    x_axis = 300

    # org denotes the bottom-left of the first character
    img = cv2.putText(img=img,
                      text="Please ... ",
                      org=(x_axis, y_axis),
                      fontFace=font,
                      fontScale=1.2,
                      color=(255, 255, 255),
                      thickness=2)

    cv2.imshow(img_name, img)

    cv2.waitKey()

    cv2.destroyAllWindows()

# ----------------------------------------------------------------------------------------------------------------------
put_text_def_1(img_name="Tips")
# ----------------------------------------------------------------------------------------------------------------------
