# encoding=utf-8
# Date: 2020-01-28
# Author: Weijia Bei


import cv2
import os


def show_img_by_cv2(
    img, img_file_name
):
    cv2.imshow(img_file_name, img)

    cv2.waitKey()

    cv2.destroyAllWindows()


def show_ground_truth_def_1(
        img, img_file_name, ground_truth_coor_list,
        scale=1
):
    # curr_h, curr_w = ..., ...
    curr_h, curr_w = img.shape[: 2]

    img = cv2.resize(
        img,
        (round(curr_w / scale), round(curr_h / scale))
    )

    cv2.namedWindow(img_file_name,
                    cv2.WINDOW_NORMAL)

    for coor in ground_truth_coor_list:

        row = coor[0] // scale
        col = coor[1] // scale

        x = col
        y = row

        cv2.circle(img=img,
                   center=(x, y),
                   radius=5,
                   color=(255, 0, 0),
                   thickness=-1)

    cv2.imshow(img_file_name, img)

    cv2.waitKey()

    cv2.destroyAllWindows()


"""
# ----------------------------------------------------------------------------------------------------------------------
image_path_sample_1 = 'D:/Dataset_kuzushiji/train_images\\100241706_00005_1.jpg'

img_1 = cv2.cvtColor(cv2.imread(image_path_sample_1,
                                flags=1),
                     cv2.COLOR_BGR2RGB)

# ground_truth_coor_list.sample: [[row, col], [row, col], ...]
show_ground_truth_def_1(img=img_1,
                        img_file_name=os.path.basename(image_path_sample_1),
                        ground_truth_coor_list=[
                            [100, 150],
                            [150, 150],
                            [200, 150],
                            [250, 150],
                            [300, 150]
                        ])
# ----------------------------------------------------------------------------------------------------------------------
"""
