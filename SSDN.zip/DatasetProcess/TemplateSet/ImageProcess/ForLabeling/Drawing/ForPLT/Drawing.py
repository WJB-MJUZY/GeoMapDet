# encoding=utf-8
# Date: 2020-01-30
# Author: Weijia Bei


import cv2
import matplotlib.pyplot as plt


def plt_show_ground_truth_def_1(
        img, ground_truth_coor_list
):
    fig = plt.figure()

    axi = fig.add_subplot(1, 1, 1)

    for coor in ground_truth_coor_list:

        row = int(coor[0])
        col = int(coor[1])

        x = col
        y = row

        axi.scatter(x, y)

        plt.axis("off")

        fig.canvas.draw()

    axi.imshow(img)

    plt.axis("off")

    plt.show()

"""
# ----------------------------------------------------------------------------------------------------------------------
image_path_sample_1 = 'D:/Dataset_kuzushiji/train_images\\100241706_00005_1.jpg'

img_1 = cv2.cvtColor(cv2.imread(image_path_sample_1,
                                flags=1),
                     cv2.COLOR_BGR2RGB)

# ground_truth_coor_list.sample: [[row, col], [row, col], ...]
plt_show_ground_truth_def_1(img=img_1,
                            ground_truth_coor_list=[
                                [100, 150],
                                [150, 150],
                                [200, 150],
                                [250, 150],
                                [300, 150]
                            ])
# ----------------------------------------------------------------------------------------------------------------------
"""
