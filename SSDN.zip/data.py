# encoding=utf-8
# Date: 2020-01-22
# Author: Weijia Bei


from albumentations import \
    Compose, RandomCrop, BboxParams, \
    ToGray, RGBShift, ChannelShuffle

from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import cv2

from .DatasetProcess.TemplateSet.ImageProcess.ForLabeling.Drawing.ForCV2.Drawing import \
    show_ground_truth_def_1, \
    show_img_by_cv2
from .DatasetProcess.TemplateSet.ImageProcess.ForLabeling.showPicture import show_picture_def_2

import numpy as np
import os
import pandas as pd
from .time import getDateStringName

import torch as th
import torch.utils.data as data

from tqdm import tqdm
# ----------------------------------------------------------------------------------------------------------------------


tqdm.monitor_interval = 0

global_image_count = 0


class TemplateDataset(data.Dataset):

    def __init__(self, image_fns, gt_boxes=None,
                 label_to_int=None,
                 augment=False,
                 height=1536,
                 width=1536,
                 feature_scale=0.25,
                 if_see_result=False):

        self.image_fns = image_fns
        self.gt_boxes = gt_boxes
        self.label_to_int = label_to_int

        self.augment = augment

        self.aug = Compose(
            [
                RandomCrop(512, 512, p=1.0),
                ToGray(),
                ChannelShuffle(),
                RGBShift(),
            ],
            bbox_params=BboxParams(format='coco', min_visibility=0.75)
        )

        self.encoded_cache = None

        self.height = height
        self.width = width

        self.feature_scale = feature_scale

        self.if_see_result = if_see_result

    def cache(self):

        self.encoded_cache = {}

        print("Caching ... ")

        with ThreadPoolExecutor() as e:

            encoded_imgs = list(
                tqdm(
                    e.map(self.read_encoded, self.image_fns),
                    total=len(self.image_fns)
                )
            )
        for fn, encoded in zip(self.image_fns, encoded_imgs):

            self.encoded_cache[fn] = encoded

    @staticmethod
    def read_encoded(fn):

        with open(fn, 'rb') as f:
            img_bytes = np.frombuffer(f.read(), dtype=np.uint8)

        return img_bytes

    @staticmethod
    def fn_to_id(fn):
        return os.path.splitext(os.path.basename(fn))[0]

    def boxes_to_mask_centers_classes(self, boxes,
                                      height=1024, width=1024,
                                      scale_x=1.0, scale_y=1.0,
                                      feature_scale=0.25,
                                      num_max_samples=620 * 9):

        mask = np.zeros(
            (int(height * feature_scale), int(width * feature_scale)),
            dtype=np.float32
        )

        centers = -1 * np.ones(
            (num_max_samples, 2), dtype=np.int64
        )

        classes = -1 * np.ones(
            (num_max_samples,), dtype=np.int64
        )

        mask = np.pad(
            mask,
            ((1, 1), (1, 1)),
            mode='constant'
        )

        pos_kernel = np.float32(
            [
                [0.5, 0.75, 0.5],
                [0.75, 1.0, 0.75],
                [0.5, 0.75, 0.5]
            ]
        )

        center_ind = 0

        for box in boxes:

            x, y, \
                w, h, \
                ll = box

            cx, cy = \
                feature_scale * scale_x * (x + w / 2), \
                feature_scale * scale_y * (y + h / 2)

            cx, cy = int(round(cx)), int(round(cy))

            if cy >= (mask.shape[0] - 2) or cx >= (mask.shape[1] - 2):
                continue

            mask[cy: cy + 3, cx: cx + 3] = pos_kernel

            label_int = self.label_to_int[ll]

            for x_offset in [-1, 0, 1]:

                cxx = cx + x_offset

                if cxx < 0 or cxx >= mask.shape[1] - 2:
                    continue

                for y_offset in [-1, 0, 1]:

                    cyy = cy + y_offset

                    if cyy < 0 or cyy >= mask.shape[0] - 2:
                        continue

                    centers[center_ind] = cxx, cyy
                    classes[center_ind] = label_int

                    center_ind += 1

        mask = mask[1: -1, 1: -1]

        return mask, centers, classes

    @staticmethod
    def mask_to_rle(img, mask_value=255, transpose=True):

        img = np.int32(img)

        if transpose:
            img = img.T

        img = img.flatten()

        img[img == mask_value] = 1

        pimg = np.pad(img, 1, mode='constant')

        diff = np.diff(pimg)

        starts = np.where(diff == 1)[0]
        ends = np.where(diff == -1)[0]

        rle = []

        previous_end = 0

        for start, end in zip(starts, ends):

            relative_start = start - previous_end

            length = end - start

            previous_end = end

            rle.append(str(relative_start))

            rle.append(str(length))

        if len(rle) == 0:
            return "-1"

        return " ".join(rle)

    @staticmethod
    def get_paddings(h, w, ratio):

        current_ratio = h / w

        # pad height
        if current_ratio < ratio:

            pad_h = int(w * ratio - h)

            pad_top = pad_h // 2
            pad_bottom = pad_h - pad_top
            pad_left, pad_right = 0, 0

        # pad width
        else:

            # current_ratio > ratio

            pad_w = int(h / ratio - w)

            pad_left = pad_w // 2
            pad_right = pad_w - pad_left
            pad_top, pad_bottom = 0, 0

        return pad_top, pad_bottom, pad_left, pad_right

    @staticmethod
    def pad_to_ratio(img, ratio):

        h, w = img.shape[: 2]

        pad_top, pad_bottom, \
            pad_left, pad_right = \
            TemplateDataset.get_paddings(
                h, w, ratio
            )

        paddings = ((pad_top, pad_bottom), (pad_left, pad_right), (0, 0))

        img = np.pad(img, paddings, mode='constant')

        return img, pad_top, pad_left

    def __getitem__(self, index, to_tensor=True):

        fn = self.image_fns[index]

        if self.encoded_cache is not None:

            encoded_img = self.encoded_cache[fn]

            img = cv2.imdecode(encoded_img, 1)

            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        else:

            img = cv2.cvtColor(cv2.imread(fn, 1), cv2.COLOR_BGR2RGB)
        # --------------------------------------------------------------------------------------------------------------

        global global_image_count
        global_image_count += 1

        print("Log: global_image_count:", global_image_count)
        # ----------------------------------------------------------------------------------------------------------

        if self.if_see_result:

            show_picture_def_2(
                img,
                one_grid_length_for_height=1,
                one_grid_length_for_row=1,
                plt_show_id=1
            )

            image_path = \
                '.' + '/' + \
                getDateStringName() + "_ori_" + \
                str(global_image_count) + \
                "." + "jpg"

            print("\nLog: image_path:", image_path)

            cv2.imwrite(
                image_path,
                img, [int(cv2.IMWRITE_JPEG_QUALITY), 100]
            )
        # --------------------------------------------------------------------------------------------------------------

        assert img.ndim == 3
        # --------------------------------------------------------------------------------------------------------------

        if self.gt_boxes is not None:

            gt_boxes = self.gt_boxes[self.fn_to_id(fn)][:]

            for box_ind in range(len(gt_boxes)):

                x_min, y_min, box_w, box_h, ll = gt_boxes[box_ind]

                if box_w > self.width - x_min:

                    print("W out")
                    box_w = self.width - x_min

                if box_h > self.height - y_min:

                    print("H out")
                    box_h = self.height - y_min

                gt_boxes[box_ind] = (x_min, y_min, box_w, box_h, ll)
            # ----------------------------------------------------------------------------------------------------------

            if self.augment:

                # img.sample.shape = (1536, 1536, 3)
                #   gt_boxes.sample = {list} [
                #       (219.5119726339795, 479.0514314669369,
                #       35.61231470923603, 12.842158601469471, 'U+306F'),
                #       ...,
                #   ]
                augmented = self.aug(image=img, bboxes=gt_boxes)

                # img.sample.shape = (512, 512, 3)
                #   gt_boxes.sample = {list} [
                #       ... (the same as above)
                #   ]
                img, gt_boxes = augmented['image'], augmented['bboxes']

            # curr_h, curr_w = 512, 512
            curr_h, curr_w = img.shape[: 2]
            # ----------------------------------------------------------------------------------------------------------

            if self.if_see_result:

                coor_list_for_gt_show = list()

                for box_ind in range(len(gt_boxes)):

                    x_min, y_min, box_w, box_h, ll = gt_boxes[box_ind]

                    x_top_left = x_min
                    y_top_left = y_min

                    x_top_right = x_min + box_w
                    y_top_right = y_min

                    x_bottom_left = x_min
                    y_bottom_left = y_min + box_h

                    x_bottom_right = x_min + box_w
                    y_bottom_right = y_min + box_h

                    # Attention: [row, col]
                    coor_list_for_gt_show.append([int(y_top_left), int(x_top_left)])
                    coor_list_for_gt_show.append([int(y_top_right), int(x_top_right)])
                    coor_list_for_gt_show.append([int(y_bottom_left), int(x_bottom_left)])
                    coor_list_for_gt_show.append([int(y_bottom_right), int(x_bottom_right)])

                show_img_by_cv2(
                    img, img_file_name=os.path.basename(fn)
                )

                show_ground_truth_def_1(
                    img=img,
                    img_file_name=os.path.basename(fn),
                    ground_truth_coor_list=coor_list_for_gt_show
                )
            # ----------------------------------------------------------------------------------------------------------

            mask, centers, classes = \
                self.boxes_to_mask_centers_classes(
                    gt_boxes,
                    height=curr_h, width=curr_w,
                    scale_x=1.0,
                    scale_y=1.0,
                    feature_scale=self.feature_scale
                )
            # ----------------------------------------------------------------------------------------------------------

            if self.if_see_result:

                image_path = \
                    '.' + '/' + \
                    getDateStringName() + "_" + \
                    str(global_image_count) + \
                    "." + "jpg"

                print("\nLog: image_path:", image_path)

                cv2.imwrite(
                    image_path,
                    img, [int(cv2.IMWRITE_JPEG_QUALITY), 100]
                )

                image_path = \
                    '.' + '/' + \
                    getDateStringName() + "_" + \
                    str(global_image_count) + "_" + \
                    "mask" + \
                    "." + "jpg"

                cv2.imwrite(
                    image_path,
                    mask
                )
            # ----------------------------------------------------------------------------------------------------------

            if to_tensor:

                img = img.transpose((2, 0, 1))
                img = th.from_numpy(img.copy())

                mask = np.expand_dims(mask, axis=0)

                mask = th.from_numpy(mask.copy())

                centers = th.from_numpy(centers)

                classes = th.from_numpy(classes)

            return img, fn, mask, centers, classes

        assert not self.augment, "Don't"

        if to_tensor:

            if img.ndim == 2:

                img = np.expand_dims(img, 0)
            elif img.ndim == 3:

                img = img.transpose((2, 0, 1))
            else:

                assert False, img.ndim

            img = th.from_numpy(img.copy())

        return img, fn

    def __len__(self):
        return len(self.image_fns)


class MultiScaleInferenceTemplateDataset(data.Dataset):

    def __init__(self, image_fns, height, width, scales):

        self.image_fns = image_fns.copy()

        self.height = height
        self.width = width

        self.scales = scales

    def __getitem__(self,
                    index,
                    to_tensor=True):

        fn = self.image_fns[index]

        img = cv2.cvtColor(cv2.imread(fn, flags=1),
                           cv2.COLOR_BGR2RGB)

        img, pad_top, pad_left = \
            TemplateDataset.pad_to_ratio(img, ratio=0.67)

        assert img.ndim == 3

        scaled_imgs = []

        for scale in self.scales:

            h_scale = int(scale * self.height)
            w_scale = int(scale * self.width)

            simg = cv2.resize(img, (w_scale, h_scale))

            if to_tensor:
                assert simg.ndim == 3, simg.ndim

                simg = simg.transpose(
                    (2, 0, 1)
                )
                simg = th.from_numpy(simg.copy())

            scaled_imgs.append(simg)

        return scaled_imgs + [fn]

    def __len__(self):
        return len(self.image_fns)


def load_gt(fn, label_key='labels', has_height_width=True):

    labels = pd.read_csv(fn, dtype={'image_id': str, label_key: str})

    labels = labels.fillna('')

    labels_ = defaultdict(list)

    all_labels = set()

    for img_id, label_str in zip(labels['image_id'], labels[label_key]):

        img_labels = label_str.split(' ')

        if has_height_width:

            l, x, y, \
                h, w = \
                img_labels[::5], \
                img_labels[1::5], \
                img_labels[2::5], \
                img_labels[3::5], \
                img_labels[4::5]

            for ll, xx, yy, hh, ww in zip(l, x, y, h, w):

                labels_[img_id].append(
                    (int(xx), int(yy), int(hh), int(ww), ll)
                )
                all_labels.add(ll)
        else:

            l, x, y = \
                img_labels[::3], \
                img_labels[1::3], \
                img_labels[2::3]

            for ll, xx, yy in zip(l, x, y):
                labels_[img_id].append((int(xx), int(yy), ll))

                all_labels.add(ll)

    label_to_int = {
        v: k
        for k, v in enumerate(sorted(list(all_labels)))
    }
    labels = dict(labels_)

    return labels, label_to_int
