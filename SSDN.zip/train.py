# encoding=utf-8
# Date: 2020-02-21
# Author: Weijia Bei


import apex
import csv

from .data import TemplateDataset, load_gt

from .DatasetProcess.TemplateSet.ImageProcess.ForLabeling.Drawing.ForPLT.Drawing import \
    plt_show_ground_truth_def_1

from glob import glob
from .models import FPNSegmentation
import numpy as np
import os
from .time import getDateStringName

import torch as th
from torch.optim import Adam
import torch.utils.data as data

from tqdm import tqdm


tqdm.monitor_interval = 0

th.backends.cudnn.benchmark = False
th.backends.cudnn.deterministic = True


def nms(heat, kernel=3):

    pad = (kernel - 1) // 2

    hmax = th.nn.functional.max_pool2d(
        heat,
        (kernel, kernel),
        stride=1, padding=pad)

    keep = \
        (hmax == heat).float()

    return heat * keep


def seed_all():

    SEED_1 = 32

    np.random.seed(SEED_1)

    th.manual_seed(SEED_1)

    th.cuda.manual_seed(SEED_1)


def kuzushiji_loss(hm, centers, classes, hm_pred, classes_pred):

    assert hm.shape == hm_pred.shape

    hm = hm.to(hm_pred.dtype)

    hm_loss = th.nn.functional.binary_cross_entropy_with_logits(
        hm_pred,
        hm,
        reduction='mean'
    )

    classes_ = []

    for sample_ind in range(len(hm)):

        center = centers[sample_ind]

        center_mask = center[:, 0] != -1

        per_image_letters = center_mask.sum().item()

        if per_image_letters == 0:
            continue

        classes_per_img = classes[sample_ind][center_mask]

        classes_.append(classes_per_img)

    classes = th.cat(classes_, 0)

    classes_loss = th.nn.functional.cross_entropy(
        classes_pred,
        classes,
        reduction='mean'
    )

    total_loss = hm_loss + 0.1 * classes_loss

    return total_loss


def get_num_classes(label_to_int):

    max_value = 0

    for key, value in label_to_int.items():

        if int(value) > max_value:
            max_value = int(value)

    return max_value + 1


def visualize_results(
        hm_pred, classes_pred,
        X_input,
        model, config_1,
        base_w, base_h,
        int_to_label
):
    image_ids, labels = [], []

    hm_pred = hm_pred

    classes_embeddings = classes_pred

    hm_pred = \
        nms(
            hm_pred.detach()
        ).cpu().numpy()

    for j in range(len(hm_pred)):

        hmp = hm_pred[j].squeeze(0)

        hmp_thresholded = \
            hmp > 0.4

        ys, xs = np.where(hmp_thresholded)

        if len(ys) == 0:

            labels.append('')
            continue

        centers = th.stack(
            [th.tensor(xs), th.tensor(ys)], -1
        ).unsqueeze(0)

        gathered_embeddings = \
            model.gather_embeddings(
                classes_embeddings[j: j + 1],
                centers
            )

        classes_preds = model.classes(
            gathered_embeddings.unsqueeze(
                -1
            ).unsqueeze(-1)
        ).squeeze(-1).squeeze(-1)

        classes_preds = classes_preds[:, : config_1.num_classes]

        classes_preds = th.nn.functional.softmax(
            classes_preds.detach(), 1
        ).cpu().numpy()

        per_image_labels = []

        coor_list_for_gt_show = list()

        times = 4

        for center_ind in range(len(ys)):

            x, y = xs[center_ind], ys[center_ind]

            pred_probs = classes_preds[center_ind]

            pred_classes = [pred_probs.argmax()]

            coor_list_for_gt_show.append(
                [int(y) * times, int(x) * times]
            )

            for pred_class in pred_classes:

                ll = int_to_label[pred_class]

                per_image_labels.extend([ll, str(x), str(y)])
        # --------------------------------------------------------------------------------------------------------------

        X = X_input.detach().cpu().numpy()

        img = X[j]
        img = img.transpose(
            (1, 2, 0)
        )
        plt_show_ground_truth_def_1(
            img=img, ground_truth_coor_list=coor_list_for_gt_show
        )
        # ------------------------------------------------------------------------------------------------------

        w, h = base_w, base_h

        img = np.zeros((w, h))

        plt_show_ground_truth_def_1(
            img=img, ground_truth_coor_list=coor_list_for_gt_show
        )
        # --------------------------------------------------------------------------------------------------------------

    return '1'


def main(config_1):

    seed_all()

    os.makedirs(config_1.logdir, exist_ok=True)

    print("Logging to: %s" % config_1.logdir)
    # ------------------------------------------------------------------------------------------------------------------

    train_image_fns = sorted(glob(os.path.join(config_1.train_dir, '*.jpg')))
    # ------------------------------------------------------------------------------------------------------------------

    gt, label_to_int = load_gt(config_1.train_rle)

    config_1.num_classes = get_num_classes(label_to_int)

    print("Log: length of train_image_fns: ", len(train_image_fns))
    # ------------------------------------------------------------------------------------------------------------------

    train_image_fns = [
        fn for fn in train_image_fns
        if TemplateDataset.fn_to_id(fn) in gt
    ]

    train_ds = TemplateDataset(
        image_fns=train_image_fns,
        gt_boxes=gt,
        label_to_int=label_to_int, augment=config_1.if_aug
    )
    # ------------------------------------------------------------------------------------------------------------------

    if config_1.cache:

        train_ds.cache()
    # ------------------------------------------------------------------------------------------------------------------

    model = FPNSegmentation(config_1.slug,
                            num_classes=config_1.num_classes,
                            pretrained=False)
    # ------------------------------------------------------------------------------------------------------------------

    if config_1.weight is not None:

        print("Loading: %s" % config_1.weight)
        model.load_state_dict(th.load(config_1.weight))
    # ------------------------------------------------------------------------------------------------------------------

    model = model.to(config_1.device)

    no_decay = ['mean', 'std', 'bias'] + ['.bn%d.' % i for i in range(100)]

    grouped_parameters = [
        {
            'params': [],
            'weight_decay': config_1.weight_decay
        },
        {
            'params': [],
            'weight_decay': 0.0
        }
    ]

    for n, p in model.named_parameters():

        if not any(
                        nd in n
                        for nd in no_decay
        ):

            # print("Decay: %s" % n)
            grouped_parameters[0]['params'].append(p)
        else:

            # print("No Decay: %s" % n)
            grouped_parameters[1]['params'].append(p)

    optimizer = Adam(params=grouped_parameters, lr=config_1.lr)

    if config_1.apex:
        model, optimizer = apex.amp.initialize(model, optimizer, opt_level="O1",
                                               verbosity=0)
    # ------------------------------------------------------------------------------------------------------------------

    smooth = 0.1

    now_general_loss_str = None

    now_general_loss_float = None
    # ------------------------------------------------------------------------------------------------------------------

    for epoch in range(1, config_1.epochs + 1):

        smooth_loss = None

        smooth_accuracy = None

        model.train()

        train_loader = data.DataLoader(dataset=train_ds,
                                       batch_size=config_1.batch_size,
                                       shuffle=True,
                                       num_workers=config_1.num_workers,
                                       pin_memory=config_1.pin, drop_last=True)

        progress = tqdm(
            total=len(train_ds),
            smoothing=0.01
        )
        if True:

            for i, (X, fns, hm, centers, classes) in enumerate(train_loader):

                print("\nLog: this is one batch...\n")

                X = X.to(
                    config_1.device
                ).float()

                hm = hm.to(config_1.device)

                centers = centers.to(config_1.device)

                classes = classes.to(config_1.device)

                hm_pred, classes_pred = model(X, centers=centers)
                # ------------------------------------------------------------------------------------------------------

                loss = kuzushiji_loss(hm, centers, classes, hm_pred, classes_pred)
                # ------------------------------------------------------------------------------------------------------

                if config_1.apex:

                    with apex.amp.scale_loss(loss, optimizer) as scaled_loss:
                        scaled_loss.backward()
                else:
                    loss.backward()
                # ------------------------------------------------------------------------------------------------------

                lr_this_step = None

                optimizer.step()

                optimizer.zero_grad()

                for param_group in optimizer.param_groups:
                    param_group['lr'] = config_1.lr
                # ------------------------------------------------------------------------------------------------------

                smooth_loss = \
                    loss.item() \
                    if smooth_loss is None else \
                    smooth * loss.item() + (1. - smooth) * smooth_loss

                accuracy = th.mean(
                    (
                        (th.sigmoid(hm_pred) >= 0.5) == (hm == 1)
                    ).to(th.float)
                ).item()

                smooth_accuracy = \
                    accuracy \
                    if smooth_accuracy is None \
                    else smooth * accuracy + (1. - smooth) * smooth_accuracy

                progress.set_postfix(
                    ep='%d/%d' % (
                        epoch, config_1.epochs
                    ),
                    loss='%.4f' % smooth_loss, accuracy='%.4f' % smooth_accuracy,
                    lr='%.6f' % (
                        config_1.lr
                        if lr_this_step is None
                        else lr_this_step)
                )
                progress.update(len(X))
                # ------------------------------------------------------------------------------------------------------

                config_1.writer_log_record_loss_acc_csv.writerow(
                    [smooth_loss, smooth_accuracy]
                )
                # ------------------------------------------------------------------------------------------------------

        now_general_loss_str = str(smooth_loss)
        now_general_loss_float = float(now_general_loss_str)

        if config_1.loss_threshold_for_save_weight > now_general_loss_float:

            summary_str = getDateStringName() + "_" + now_general_loss_str

            weight_fn = os.path.join(config_1.logdir, summary_str + '.pth')
            print("\nLog: saving model to:", weight_fn, "\n")

            th.save(model.state_dict(), weight_fn)
        # --------------------------------------------------------------------------------------------------------------

    if not config_1.loss_threshold_for_save_weight > now_general_loss_float:

        summary_str = getDateStringName() + "_" + now_general_loss_str

        weight_fn = os.path.join(config_1.logdir, summary_str + '.pth')
        print("\nLog: saving model to:", weight_fn, "\n")

        th.save(model.state_dict(), weight_fn)
    # ------------------------------------------------------------------------------------------------------------------

    config_1.f_log_record_loss_acc_csv.close()
    # ------------------------------------------------------------------------------------------------------------------


class Config:

    def __init__(self):

        self.id = 38

        self.logdir = './Logdir'
        self.log_record_loss_acc_csv = "log_record_loss_acc_" + getDateStringName() + ".csv"
        # --------------------------------------------------------------------------------------------------------------

        self.if_aug = True

        dir_path_1_dataset_kuzushiji = "D:/Dataset_dizhitu_2/"

        self.train_dir = \
            dir_path_1_dataset_kuzushiji + 'train_images'
        self.train_rle = \
            dir_path_1_dataset_kuzushiji + 'train.csv'
        # --------------------------------------------------------------------------------------------------------------

        self.num_classes = int()
        # --------------------------------------------------------------------------------------------------------------

        self.epochs = 128

        self.batch_size = 4
        # --------------------------------------------------------------------------------------------------------------

        self.if_new_train = False

        if self.if_new_train:

            print("\nLog: config.if_new_train: ", self.if_new_train)

            self.weight = None

            mode_log_record_loss_acc_csv = "w"
        else:

            print("\nLog: config.if_new_train: ",
                  self.if_new_train)
            print("\nNow, please input the existing model filename, "
                  "to continue train: ")
            existing_model_filename = input()

            self.weight = \
                self.logdir + '/' + \
                existing_model_filename

            mode_log_record_loss_acc_csv = "a+"

        self.f_log_record_loss_acc_csv = open(self.log_record_loss_acc_csv,
                                              mode=mode_log_record_loss_acc_csv,
                                              encoding="utf-8", newline='')

        self.writer_log_record_loss_acc_csv = csv.writer(self.f_log_record_loss_acc_csv,
                                                         delimiter=',')
        # --------------------------------------------------------------------------------------------------------------

        self.device = 'cuda'

        self.apex = True

        self.base_w = 512
        self.base_h = 512
        # --------------------------------------------------------------------------------------------------------------

        self.lr = 5e-5

        self.weight_decay = 1e-4

        self.loss_threshold_for_save_weight = 0.0075
        # --------------------------------------------------------------------------------------------------------------

        self.num_workers = 0

        self.pin = False
        # --------------------------------------------------------------------------------------------------------------

        self.slug = 'r101d'
        # --------------------------------------------------------------------------------------------------------------

        self.cache = True
        # --------------------------------------------------------------------------------------------------------------

    def as_dict(self):
        return vars(self)

    def __str__(self):
        return str(self.as_dict())

    def __repr__(self):
        return str(self)


if __name__ == '__main__':

    config = Config()

    main(config)
