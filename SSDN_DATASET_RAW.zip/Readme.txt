
Please use the following url to download the related data: 

https://doi.org/10.6084/m9.figshare.13352036